:HL["/_next/static/chunks/38wd8z1kcpn0m.css","style"]
:HL["/_next/static/chunks/0783px1ztgdke.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":20,"slots":{"children":{"name":"/_not-found","param":null,"prefetchHints":0,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":0,"slots":null}}}}},"staleTime":300,"buildId":"qtfDbcv9CTGbtViq53kK9"}
