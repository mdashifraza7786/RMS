var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/menu/ingredients/route.js")
R.c("server/chunks/_152iq_i._.js")
R.c("server/chunks/[root-of-the-server]__0kgvup5._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/[root-of-the-server]__216rlm9._.js")
R.c("server/chunks/_next-internal_server_app_api_menu_ingredients_route_actions_00n8vtg.js")
R.m(47317)
module.exports=R.m(47317).exports
