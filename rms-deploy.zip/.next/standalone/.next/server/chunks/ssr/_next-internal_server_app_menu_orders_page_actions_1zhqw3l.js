module.exports=[35580,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_menu_orders_page_actions_1zhqw3l.js.map