module.exports=[78877,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_chart_waiterChart_route_actions_1am-dxj.js.map