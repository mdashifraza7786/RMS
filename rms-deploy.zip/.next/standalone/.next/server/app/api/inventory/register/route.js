var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/inventory/register/route.js")
R.c("server/chunks/_03r3nm6._.js")
R.c("server/chunks/[root-of-the-server]__0kgvup5._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/[root-of-the-server]__216rlm9._.js")
R.c("server/chunks/_next-internal_server_app_api_inventory_register_route_actions_1n1kd9d.js")
R.m(91660)
module.exports=R.m(91660).exports
