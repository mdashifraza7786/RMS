module.exports=[54971,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_recentOrder_updateOrder_route_actions_188y8t6.js.map