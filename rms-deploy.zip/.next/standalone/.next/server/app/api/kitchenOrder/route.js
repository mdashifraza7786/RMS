var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/kitchenOrder/route.js")
R.c("server/chunks/[root-of-the-server]__0qbm431._.js")
R.c("server/chunks/[root-of-the-server]__216rlm9._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_kitchenOrder_route_actions_1tzoagx.js")
R.m(76106)
module.exports=R.m(76106).exports
