module.exports=[88930,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_inventory_register_route_actions_1n1kd9d.js.map