var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/inventory/bulkOrder/route.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_0m0yyh8.js")
R.c("server/chunks/[root-of-the-server]__0kgvup5._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/[root-of-the-server]__216rlm9._.js")
R.c("server/chunks/_next-internal_server_app_api_inventory_bulkOrder_route_actions_1528pj4.js")
R.m(27042)
module.exports=R.m(27042).exports
