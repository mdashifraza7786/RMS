var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/recentOrder/delete/route.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_0h0emyi.js")
R.c("server/chunks/[root-of-the-server]__0kgvup5._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/[root-of-the-server]__216rlm9._.js")
R.c("server/chunks/_next-internal_server_app_api_recentOrder_delete_route_actions_0z6f2e7.js")
R.m(35684)
module.exports=R.m(35684).exports
