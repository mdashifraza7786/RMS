module.exports=[89869,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_order_activeOrders_route_actions_0xz5t4n.js.map