module.exports=[43635,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_order_recentPayments_route_actions_1izuoy6.js.map