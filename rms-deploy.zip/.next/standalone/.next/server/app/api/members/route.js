var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/members/route.js")
R.c("server/chunks/_08cus7d._.js")
R.c("server/chunks/[root-of-the-server]__0kgvup5._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/[root-of-the-server]__216rlm9._.js")
R.c("server/chunks/_next-internal_server_app_api_members_route_actions_0wpc9k-.js")
R.m(17139)
module.exports=R.m(17139).exports
