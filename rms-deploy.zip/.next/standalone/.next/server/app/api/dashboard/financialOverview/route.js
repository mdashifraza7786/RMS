var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/dashboard/financialOverview/route.js")
R.c("server/chunks/_1i-e68k._.js")
R.c("server/chunks/[root-of-the-server]__0kgvup5._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/[root-of-the-server]__216rlm9._.js")
R.c("server/chunks/_next-internal_server_app_api_dashboard_financialOverview_route_actions_1pdwhdh.js")
R.m(96460)
module.exports=R.m(96460).exports
