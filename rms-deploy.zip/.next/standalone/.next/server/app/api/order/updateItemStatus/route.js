var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/order/updateItemStatus/route.js")
R.c("server/chunks/[root-of-the-server]__125hfp0._.js")
R.c("server/chunks/[root-of-the-server]__0kgvup5._.js")
R.c("server/chunks/[root-of-the-server]__216rlm9._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_0rw1qr8._.js")
R.c("server/chunks/_next-internal_server_app_api_order_updateItemStatus_route_actions_1v0uzry.js")
R.m(74160)
module.exports=R.m(74160).exports
