module.exports=[27077,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_orders_active_page_actions_1rkwzhe.js.map