var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/attendance/generate/route.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_1592n4m.js")
R.c("server/chunks/[root-of-the-server]__0kgvup5._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/[root-of-the-server]__216rlm9._.js")
R.c("server/chunks/_next-internal_server_app_api_attendance_generate_route_actions_0n2b9jf.js")
R.m(95584)
module.exports=R.m(95584).exports
