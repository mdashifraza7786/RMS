var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/attendance/staff/route.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_1uh4px0.js")
R.c("server/chunks/[root-of-the-server]__0kgvup5._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/[root-of-the-server]__216rlm9._.js")
R.c("server/chunks/_next-internal_server_app_api_attendance_staff_route_actions_02w4ap_.js")
R.m(42564)
module.exports=R.m(42564).exports
