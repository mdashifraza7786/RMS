module.exports=[94765,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_recentOrder_delete_route_actions_0z6f2e7.js.map