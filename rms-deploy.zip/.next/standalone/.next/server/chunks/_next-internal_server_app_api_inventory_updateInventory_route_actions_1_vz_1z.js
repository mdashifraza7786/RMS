module.exports=[7097,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_inventory_updateInventory_route_actions_1_vz_1z.js.map