module.exports=[17008,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_expenses_update_route_actions_1lld6ut.js.map