module.exports=[30721,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_members_delete_route_actions_1lup_yc.js.map