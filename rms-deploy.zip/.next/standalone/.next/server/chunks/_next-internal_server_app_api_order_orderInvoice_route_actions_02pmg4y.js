module.exports=[10375,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_order_orderInvoice_route_actions_02pmg4y.js.map