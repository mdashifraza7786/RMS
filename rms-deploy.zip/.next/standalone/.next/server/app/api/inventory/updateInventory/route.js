var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/inventory/updateInventory/route.js")
R.c("server/chunks/[root-of-the-server]__0lc0xyt._.js")
R.c("server/chunks/[root-of-the-server]__0kgvup5._.js")
R.c("server/chunks/[root-of-the-server]__216rlm9._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_0rw1qr8._.js")
R.c("server/chunks/_next-internal_server_app_api_inventory_updateInventory_route_actions_1_vz_1z.js")
R.m(52582)
module.exports=R.m(52582).exports
