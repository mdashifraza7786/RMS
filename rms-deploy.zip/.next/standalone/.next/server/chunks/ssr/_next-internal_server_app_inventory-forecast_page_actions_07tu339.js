module.exports=[2128,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_inventory-forecast_page_actions_07tu339.js.map