:HL["/_next/static/chunks/38wd8z1kcpn0m.css","style"]
:HL["/_next/static/chunks/0783px1ztgdke.css","style"]
:HL["/_next/static/media/c825fd02acae0153-s.p.1q3-y3vmyf3p6.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
0:{"tree":{"name":"","param":null,"prefetchHints":20,"slots":{"children":{"name":"attendance","param":null,"prefetchHints":0,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":0,"slots":null}}}}},"staleTime":300,"buildId":"qtfDbcv9CTGbtViq53kK9"}
