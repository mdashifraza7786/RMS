1:"$Sreact.fragment"
2:I[22016,["/_next/static/chunks/1udoi73icbe2w.js","/_next/static/chunks/1-8s9_t85wwr4.js","/_next/static/chunks/2ac6h--5t76rz.js","/_next/static/chunks/11niemaajhmcl.js","/_next/static/chunks/3xyt402c62511.js"],""]
3:I[97367,["/_next/static/chunks/1udoi73icbe2w.js","/_next/static/chunks/1-8s9_t85wwr4.js","/_next/static/chunks/2ac6h--5t76rz.js","/_next/static/chunks/11niemaajhmcl.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":[["$","div",null,{"className":"w-full h-[60vh]  flex flex-col gap-14 justify-center items-center","children":[["$","h1",null,{"className":"text-3xl font-bold","children":"Page not found"}],["$","$L2",null,{"href":"/","children":["$","button",null,{"className":"bg-primary px-5 py-3 text-white font-semibold rounded-lg hover:bg-white hover:text-black","children":"Go Back To Home"}]}]]}],[["$","script","script-0",{"src":"/_next/static/chunks/3xyt402c62511.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"qtfDbcv9CTGbtViq53kK9"}
5:null
