var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/chart/profitLossChart/route.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_0c1e2fy.js")
R.c("server/chunks/[root-of-the-server]__0kgvup5._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/[root-of-the-server]__216rlm9._.js")
R.c("server/chunks/_next-internal_server_app_api_chart_profitLossChart_route_actions_03dpf0p.js")
R.m(21070)
module.exports=R.m(21070).exports
