var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/inventory/forecast/route.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_0b1dfcy.js")
R.c("server/chunks/[root-of-the-server]__0kgvup5._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/[root-of-the-server]__216rlm9._.js")
R.c("server/chunks/_next-internal_server_app_api_inventory_forecast_route_actions_0e16u-j.js")
R.m(7220)
module.exports=R.m(7220).exports
