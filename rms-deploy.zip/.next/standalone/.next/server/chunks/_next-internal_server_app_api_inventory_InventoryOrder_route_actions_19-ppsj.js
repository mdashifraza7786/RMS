module.exports=[23261,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_inventory_InventoryOrder_route_actions_19-ppsj.js.map