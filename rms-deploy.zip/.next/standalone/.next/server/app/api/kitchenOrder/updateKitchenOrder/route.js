var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/kitchenOrder/updateKitchenOrder/route.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_0es6j_w.js")
R.c("server/chunks/[root-of-the-server]__0kgvup5._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/[root-of-the-server]__216rlm9._.js")
R.c("server/chunks/1oeh_server_app_api_kitchenOrder_updateKitchenOrder_route_actions_09dhkso.js")
R.m(33022)
module.exports=R.m(33022).exports
