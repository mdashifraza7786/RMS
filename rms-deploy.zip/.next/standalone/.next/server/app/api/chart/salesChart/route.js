var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/chart/salesChart/route.js")
R.c("server/chunks/[root-of-the-server]__0kgvup5._.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_0_ie1fl.js")
R.c("server/chunks/[root-of-the-server]__216rlm9._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_chart_salesChart_route_actions_1mr4vxn.js")
R.m(69092)
module.exports=R.m(69092).exports
