var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/menu/delete/route.js")
R.c("server/chunks/[root-of-the-server]__1vo2i6a._.js")
R.c("server/chunks/[root-of-the-server]__0kgvup5._.js")
R.c("server/chunks/[root-of-the-server]__216rlm9._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_0rw1qr8._.js")
R.c("server/chunks/_next-internal_server_app_api_menu_delete_route_actions_0y-x94y.js")
R.m(16342)
module.exports=R.m(16342).exports
