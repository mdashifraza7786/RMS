1:"$Sreact.fragment"
2:I[39756,["/_next/static/chunks/1udoi73icbe2w.js","/_next/static/chunks/1-8s9_t85wwr4.js","/_next/static/chunks/2ac6h--5t76rz.js","/_next/static/chunks/11niemaajhmcl.js"],"default"]
3:I[37457,["/_next/static/chunks/1udoi73icbe2w.js","/_next/static/chunks/1-8s9_t85wwr4.js","/_next/static/chunks/2ac6h--5t76rz.js","/_next/static/chunks/11niemaajhmcl.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"qtfDbcv9CTGbtViq53kK9"}
