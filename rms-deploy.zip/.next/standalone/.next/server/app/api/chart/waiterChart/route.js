var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/chart/waiterChart/route.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_1l3rlmg.js")
R.c("server/chunks/[root-of-the-server]__0kgvup5._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/[root-of-the-server]__216rlm9._.js")
R.c("server/chunks/_next-internal_server_app_api_chart_waiterChart_route_actions_1am-dxj.js")
R.m(8925)
module.exports=R.m(8925).exports
