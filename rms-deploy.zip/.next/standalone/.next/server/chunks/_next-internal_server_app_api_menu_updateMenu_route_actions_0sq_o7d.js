module.exports=[33085,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_menu_updateMenu_route_actions_0sq_o7d.js.map