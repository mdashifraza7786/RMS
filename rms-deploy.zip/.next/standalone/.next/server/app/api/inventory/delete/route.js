var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/inventory/delete/route.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_01ghncc.js")
R.c("server/chunks/[root-of-the-server]__0kgvup5._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/[root-of-the-server]__216rlm9._.js")
R.c("server/chunks/_next-internal_server_app_api_inventory_delete_route_actions_0akksdl.js")
R.m(99046)
module.exports=R.m(99046).exports
