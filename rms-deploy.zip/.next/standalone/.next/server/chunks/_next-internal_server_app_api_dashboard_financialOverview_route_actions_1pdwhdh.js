module.exports=[2084,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_dashboard_financialOverview_route_actions_1pdwhdh.js.map