var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/recentOrder/updateOrder/route.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_0s9hym8.js")
R.c("server/chunks/[root-of-the-server]__0kgvup5._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/[root-of-the-server]__216rlm9._.js")
R.c("server/chunks/_next-internal_server_app_api_recentOrder_updateOrder_route_actions_188y8t6.js")
R.m(90907)
module.exports=R.m(90907).exports
