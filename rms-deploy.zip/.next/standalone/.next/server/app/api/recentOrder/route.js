var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/recentOrder/route.js")
R.c("server/chunks/[root-of-the-server]__1iydzhc._.js")
R.c("server/chunks/[root-of-the-server]__216rlm9._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_recentOrder_route_actions_1dljpc8.js")
R.m(44034)
module.exports=R.m(44034).exports
