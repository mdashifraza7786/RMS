var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/order/void/[orderID]/route.js")
R.c("server/chunks/[root-of-the-server]__0nneqdm._.js")
R.c("server/chunks/[root-of-the-server]__0kgvup5._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/[root-of-the-server]__216rlm9._.js")
R.c("server/chunks/_0rw1qr8._.js")
R.c("server/chunks/_next-internal_server_app_api_order_void_[orderID]_route_actions_1re74-2.js")
R.m(83500)
module.exports=R.m(83500).exports
