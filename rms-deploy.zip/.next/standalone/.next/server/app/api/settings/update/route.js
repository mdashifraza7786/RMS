var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/settings/update/route.js")
R.c("server/chunks/[root-of-the-server]__154pxrf._.js")
R.c("server/chunks/[root-of-the-server]__0kgvup5._.js")
R.c("server/chunks/[root-of-the-server]__216rlm9._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_0rw1qr8._.js")
R.c("server/chunks/_next-internal_server_app_api_settings_update_route_actions_10dn5-2.js")
R.m(10903)
module.exports=R.m(10903).exports
