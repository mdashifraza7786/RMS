var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/order/placeOrder/[orderID]/route.js")
R.c("server/chunks/_1-us90r._.js")
R.c("server/chunks/[root-of-the-server]__0kgvup5._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/[root-of-the-server]__216rlm9._.js")
R.c("server/chunks/_next-internal_server_app_api_order_placeOrder_[orderID]_route_actions_10r5272.js")
R.m(18607)
module.exports=R.m(18607).exports
