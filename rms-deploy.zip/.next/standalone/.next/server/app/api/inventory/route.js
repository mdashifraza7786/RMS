var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/inventory/route.js")
R.c("server/chunks/_1gsipwj._.js")
R.c("server/chunks/[root-of-the-server]__0kgvup5._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/[root-of-the-server]__216rlm9._.js")
R.c("server/chunks/_next-internal_server_app_api_inventory_route_actions_1j058gl.js")
R.m(84464)
module.exports=R.m(84464).exports
