var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/members/[userid]/route.js")
R.c("server/chunks/[root-of-the-server]__103n23p._.js")
R.c("server/chunks/[root-of-the-server]__0kgvup5._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/[root-of-the-server]__216rlm9._.js")
R.c("server/chunks/_0rw1qr8._.js")
R.c("server/chunks/_next-internal_server_app_api_members_[userid]_route_actions_1os5zft.js")
R.m(47569)
module.exports=R.m(47569).exports
