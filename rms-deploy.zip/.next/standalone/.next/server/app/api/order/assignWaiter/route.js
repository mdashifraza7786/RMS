var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/order/assignWaiter/route.js")
R.c("server/chunks/[root-of-the-server]__1n0rsv5._.js")
R.c("server/chunks/[root-of-the-server]__0kgvup5._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/[root-of-the-server]__216rlm9._.js")
R.c("server/chunks/_0rw1qr8._.js")
R.c("server/chunks/_next-internal_server_app_api_order_assignWaiter_route_actions_1kufozo.js")
R.m(94885)
module.exports=R.m(94885).exports
