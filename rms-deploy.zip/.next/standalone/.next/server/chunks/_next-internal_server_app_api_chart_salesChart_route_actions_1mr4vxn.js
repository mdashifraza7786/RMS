module.exports=[41948,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_chart_salesChart_route_actions_1mr4vxn.js.map