var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/attendance/updateAttendence/route.js")
R.c("server/chunks/[root-of-the-server]__0-8haa2._.js")
R.c("server/chunks/[root-of-the-server]__0kgvup5._.js")
R.c("server/chunks/[root-of-the-server]__216rlm9._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_0rw1qr8._.js")
R.c("server/chunks/_next-internal_server_app_api_attendance_updateAttendence_route_actions_1cf-ktw.js")
R.m(43135)
module.exports=R.m(43135).exports
