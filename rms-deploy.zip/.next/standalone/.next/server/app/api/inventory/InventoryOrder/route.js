var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/inventory/InventoryOrder/route.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_1m6golb.js")
R.c("server/chunks/[root-of-the-server]__0kgvup5._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/[root-of-the-server]__216rlm9._.js")
R.c("server/chunks/_next-internal_server_app_api_inventory_InventoryOrder_route_actions_19-ppsj.js")
R.m(8269)
module.exports=R.m(8269).exports
