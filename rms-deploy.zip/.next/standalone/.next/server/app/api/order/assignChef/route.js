var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/order/assignChef/route.js")
R.c("server/chunks/_1k9o_7r._.js")
R.c("server/chunks/[root-of-the-server]__0kgvup5._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/[root-of-the-server]__216rlm9._.js")
R.c("server/chunks/_next-internal_server_app_api_order_assignChef_route_actions_0za5p95.js")
R.m(24509)
module.exports=R.m(24509).exports
