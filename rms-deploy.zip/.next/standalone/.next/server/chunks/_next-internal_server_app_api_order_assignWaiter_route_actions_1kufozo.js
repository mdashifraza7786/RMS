module.exports=[59769,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_order_assignWaiter_route_actions_1kufozo.js.map