var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/order/modifyOrder/route.js")
R.c("server/chunks/[root-of-the-server]__0ndhht1._.js")
R.c("server/chunks/[root-of-the-server]__0kgvup5._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/[root-of-the-server]__216rlm9._.js")
R.c("server/chunks/_0rw1qr8._.js")
R.c("server/chunks/_next-internal_server_app_api_order_modifyOrder_route_actions_0v2temw.js")
R.m(40514)
module.exports=R.m(40514).exports
