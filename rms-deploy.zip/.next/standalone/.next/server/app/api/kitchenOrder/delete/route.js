var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/kitchenOrder/delete/route.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_1s9nhhv.js")
R.c("server/chunks/[root-of-the-server]__0kgvup5._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/[root-of-the-server]__216rlm9._.js")
R.c("server/chunks/_next-internal_server_app_api_kitchenOrder_delete_route_actions_0x4trx8.js")
R.m(40442)
module.exports=R.m(40442).exports
