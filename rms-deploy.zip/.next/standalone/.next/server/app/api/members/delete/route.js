var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/members/delete/route.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_03xs7zl.js")
R.c("server/chunks/[root-of-the-server]__0kgvup5._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/[root-of-the-server]__216rlm9._.js")
R.c("server/chunks/_next-internal_server_app_api_members_delete_route_actions_1lup_yc.js")
R.m(65559)
module.exports=R.m(65559).exports
