var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/tables/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__0cmvf2j._.js")
R.c("server/chunks/[root-of-the-server]__0kgvup5._.js")
R.c("server/chunks/[root-of-the-server]__216rlm9._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_0rw1qr8._.js")
R.c("server/chunks/_next-internal_server_app_api_tables_[id]_route_actions_0udp12k.js")
R.m(36836)
module.exports=R.m(36836).exports
