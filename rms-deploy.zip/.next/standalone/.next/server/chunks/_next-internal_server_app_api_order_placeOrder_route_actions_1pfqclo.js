module.exports=[99338,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_order_placeOrder_route_actions_1pfqclo.js.map