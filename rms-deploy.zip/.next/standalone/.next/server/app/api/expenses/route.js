var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/expenses/route.js")
R.c("server/chunks/_1dcncuo._.js")
R.c("server/chunks/[root-of-the-server]__0kgvup5._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/[root-of-the-server]__216rlm9._.js")
R.c("server/chunks/_next-internal_server_app_api_expenses_route_actions_1q06stf.js")
R.m(32220)
module.exports=R.m(32220).exports
