module.exports=[93897,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_settings_update_route_actions_10dn5-2.js.map