module.exports=[99640,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_inventory_bulkOrder_route_actions_1528pj4.js.map