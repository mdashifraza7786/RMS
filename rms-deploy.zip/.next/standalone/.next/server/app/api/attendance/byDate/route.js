var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/attendance/byDate/route.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_026k7aw.js")
R.c("server/chunks/[root-of-the-server]__0kgvup5._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/[root-of-the-server]__216rlm9._.js")
R.c("server/chunks/_next-internal_server_app_api_attendance_byDate_route_actions_0o888yu.js")
R.m(45590)
module.exports=R.m(45590).exports
