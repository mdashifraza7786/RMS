1:"$Sreact.fragment"
2:I[97367,["/_next/static/chunks/1udoi73icbe2w.js","/_next/static/chunks/1-8s9_t85wwr4.js","/_next/static/chunks/2ac6h--5t76rz.js","/_next/static/chunks/11niemaajhmcl.js"],"ViewportBoundary"]
3:I[97367,["/_next/static/chunks/1udoi73icbe2w.js","/_next/static/chunks/1-8s9_t85wwr4.js","/_next/static/chunks/2ac6h--5t76rz.js","/_next/static/chunks/11niemaajhmcl.js"],"MetadataBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","h",{"children":[null,["$","$L2",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1, maximum-scale=5, user-scalable=yes"}]]}],["$","div",null,{"hidden":true,"children":["$","$L3",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"Dashboard"}]]}]}]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"qtfDbcv9CTGbtViq53kK9"}
