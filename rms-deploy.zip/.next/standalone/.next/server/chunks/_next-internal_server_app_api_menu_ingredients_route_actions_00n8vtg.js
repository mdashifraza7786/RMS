module.exports=[12703,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_menu_ingredients_route_actions_00n8vtg.js.map