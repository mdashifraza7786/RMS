module.exports=[97656,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_tables_%5Bid%5D_route_actions_0udp12k.js.map