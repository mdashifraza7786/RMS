var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/settings/route.js")
R.c("server/chunks/[root-of-the-server]__1-le61y._.js")
R.c("server/chunks/[root-of-the-server]__0kgvup5._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/[root-of-the-server]__216rlm9._.js")
R.c("server/chunks/_0rw1qr8._.js")
R.c("server/chunks/_next-internal_server_app_api_settings_route_actions_1bpm9ac.js")
R.m(61525)
module.exports=R.m(61525).exports
