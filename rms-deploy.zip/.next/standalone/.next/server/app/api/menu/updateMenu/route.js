var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/menu/updateMenu/route.js")
R.c("server/chunks/[root-of-the-server]__19725vv._.js")
R.c("server/chunks/[root-of-the-server]__0kgvup5._.js")
R.c("server/chunks/[root-of-the-server]__216rlm9._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_0rw1qr8._.js")
R.c("server/chunks/_next-internal_server_app_api_menu_updateMenu_route_actions_0sq_o7d.js")
R.m(63222)
module.exports=R.m(63222).exports
