var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/change-password/route.js")
R.c("server/chunks/[root-of-the-server]__0ms-6dr._.js")
R.c("server/chunks/[root-of-the-server]__0kgvup5._.js")
R.c("server/chunks/[root-of-the-server]__216rlm9._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_0rw1qr8._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_change-password_route_actions_0dcnj10.js")
R.m(56219)
module.exports=R.m(56219).exports
