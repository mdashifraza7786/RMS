var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/order/voidItem/route.js")
R.c("server/chunks/[root-of-the-server]__1jlsaiu._.js")
R.c("server/chunks/[root-of-the-server]__0kgvup5._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/[root-of-the-server]__216rlm9._.js")
R.c("server/chunks/_0rw1qr8._.js")
R.c("server/chunks/_next-internal_server_app_api_order_voidItem_route_actions_0nxi9n6.js")
R.m(29517)
module.exports=R.m(29517).exports
