var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/order/recentPayments/route.js")
R.c("server/chunks/_1561qqy._.js")
R.c("server/chunks/[root-of-the-server]__0kgvup5._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/[root-of-the-server]__216rlm9._.js")
R.c("server/chunks/_next-internal_server_app_api_order_recentPayments_route_actions_1izuoy6.js")
R.m(42398)
module.exports=R.m(42398).exports
