module.exports=[31505,(e,o,d)=>{}];

//# sourceMappingURL=1oeh_server_app_api_kitchenOrder_updateKitchenOrder_route_actions_09dhkso.js.map