var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/order/orderInvoice/route.js")
R.c("server/chunks/_0lfcqgh._.js")
R.c("server/chunks/[root-of-the-server]__0kgvup5._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/[root-of-the-server]__216rlm9._.js")
R.c("server/chunks/_next-internal_server_app_api_order_orderInvoice_route_actions_02pmg4y.js")
R.m(83502)
module.exports=R.m(83502).exports
