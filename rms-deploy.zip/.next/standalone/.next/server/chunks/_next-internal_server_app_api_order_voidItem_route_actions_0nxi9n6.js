module.exports=[62384,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_order_voidItem_route_actions_0nxi9n6.js.map