module.exports=[67511,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_order_modifyOrder_route_actions_0v2temw.js.map