module.exports=[98511,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_chart_chefChart_route_actions_0ly_wvk.js.map