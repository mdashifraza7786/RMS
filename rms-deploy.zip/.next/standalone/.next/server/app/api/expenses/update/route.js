var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/expenses/update/route.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_1el72uk.js")
R.c("server/chunks/[root-of-the-server]__0kgvup5._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/[root-of-the-server]__216rlm9._.js")
R.c("server/chunks/_next-internal_server_app_api_expenses_update_route_actions_1lld6ut.js")
R.m(73893)
module.exports=R.m(73893).exports
