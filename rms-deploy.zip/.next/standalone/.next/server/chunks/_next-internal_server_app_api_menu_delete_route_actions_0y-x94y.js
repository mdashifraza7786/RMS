module.exports=[39427,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_menu_delete_route_actions_0y-x94y.js.map