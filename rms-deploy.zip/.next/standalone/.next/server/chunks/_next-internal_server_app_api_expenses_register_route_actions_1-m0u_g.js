module.exports=[20452,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_expenses_register_route_actions_1-m0u_g.js.map