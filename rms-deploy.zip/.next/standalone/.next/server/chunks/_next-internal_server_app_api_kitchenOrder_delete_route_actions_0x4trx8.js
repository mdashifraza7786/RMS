module.exports=[7385,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_kitchenOrder_delete_route_actions_0x4trx8.js.map