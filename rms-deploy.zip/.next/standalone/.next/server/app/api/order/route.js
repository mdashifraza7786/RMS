var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/order/route.js")
R.c("server/chunks/[root-of-the-server]__14p95e3._.js")
R.c("server/chunks/[root-of-the-server]__216rlm9._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_order_route_actions_0mplbz2.js")
R.m(56550)
module.exports=R.m(56550).exports
