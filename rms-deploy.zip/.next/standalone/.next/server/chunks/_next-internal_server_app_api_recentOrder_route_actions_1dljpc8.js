module.exports=[56508,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_recentOrder_route_actions_1dljpc8.js.map