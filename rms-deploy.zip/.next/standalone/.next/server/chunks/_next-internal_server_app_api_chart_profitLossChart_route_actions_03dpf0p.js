module.exports=[13428,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_chart_profitLossChart_route_actions_03dpf0p.js.map