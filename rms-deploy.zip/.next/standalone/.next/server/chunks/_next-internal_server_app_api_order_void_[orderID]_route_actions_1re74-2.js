module.exports=[45229,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_order_void_%5BorderID%5D_route_actions_1re74-2.js.map