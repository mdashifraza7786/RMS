var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/attendance/route.js")
R.c("server/chunks/_0ay-h44._.js")
R.c("server/chunks/[root-of-the-server]__0kgvup5._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/[root-of-the-server]__216rlm9._.js")
R.c("server/chunks/_next-internal_server_app_api_attendance_route_actions_1whc13v.js")
R.m(75136)
module.exports=R.m(75136).exports
