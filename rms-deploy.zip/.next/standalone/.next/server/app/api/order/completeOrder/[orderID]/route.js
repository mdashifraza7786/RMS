var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/order/completeOrder/[orderID]/route.js")
R.c("server/chunks/_00x5y9u._.js")
R.c("server/chunks/[root-of-the-server]__0kgvup5._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/[root-of-the-server]__216rlm9._.js")
R.c("server/chunks/1oeh_server_app_api_order_completeOrder_[orderID]_route_actions_0k8fhd1.js")
R.m(71798)
module.exports=R.m(71798).exports
