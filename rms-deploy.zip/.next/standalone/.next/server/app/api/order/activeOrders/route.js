var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/order/activeOrders/route.js")
R.c("server/chunks/[root-of-the-server]__0fz_26c._.js")
R.c("server/chunks/[root-of-the-server]__0kgvup5._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/[root-of-the-server]__216rlm9._.js")
R.c("server/chunks/_0rw1qr8._.js")
R.c("server/chunks/_next-internal_server_app_api_order_activeOrders_route_actions_0xz5t4n.js")
R.m(72532)
module.exports=R.m(72532).exports
